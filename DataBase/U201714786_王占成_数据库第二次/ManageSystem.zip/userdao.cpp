﻿#include "userdao.h"

UserDao::UserDao()
{

}

UserDao::~UserDao()
{

}
